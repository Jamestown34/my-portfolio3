

## Project info

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS






To connect a domain, navigate to Project > Settings > Domains and click Connect Domain.


