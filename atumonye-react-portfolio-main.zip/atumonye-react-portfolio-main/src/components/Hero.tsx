
import React from 'react';

const Hero = () => {
  return (
    <section id="profile" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 px-4 pt-20">
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row items-center justify-center gap-12 lg:gap-16">
          <div className="flex-shrink-0 animate-fade-in">
            <div className="relative">
              <img
                src="images/profilephoto.png"
                alt="Atumonye James profile picture"
                className="w-80 h-80 lg:w-96 lg:h-96 rounded-full object-cover shadow-2xl border-8 border-white"
              />
              <div className="absolute inset-0 rounded-full bg-gradient-to-t from-blue-600/20 to-transparent"></div>
            </div>
          </div>

          <div className="text-center lg:text-left max-w-2xl animate-fade-in">
            <p className="text-lg text-gray-600 mb-4">Hello, I'm</p>
            <h1 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
              Atumonye James
            </h1>
            <p className="text-xl lg:text-2xl text-gray-700 mb-8 font-medium">
              Data Scientist | AI Prompt Engineer | Funnel Engineer
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
              <a
                href="CV.pdf"
                download
                className="bg-white text-primary border-2 border-primary px-8 py-3 rounded-full font-semibold hover:bg-primary hover:text-white transition-all duration-300 hover:scale-105"
              >
                Download CV
              </a>
              <button
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-primary text-white px-8 py-3 rounded-full font-semibold hover:bg-primary/90 transition-all duration-300 hover:scale-105"
              >
                Contact Me
              </button>
            </div>

            <div className="flex justify-center lg:justify-start space-x-4">
              <a
                href="https://linkedin.com/in/atumonye-james-a81147267/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
              >
                <img src="images/linkedin.png" alt="LinkedIn" className="w-6 h-6" />
              </a>
              <a
                href="https://github.com/Jamestown34/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
              >
                <img src="images/github.png" alt="GitHub" className="w-6 h-6" />
              </a>
              <a
                href="https://twitter.com/AtumonyeJ1795/"
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
              >
                <img src="images/twitter.png" alt="Twitter" className="w-6 h-6" />
              </a>
              <a
                href="mailto:chuksjames05@gmail.com"
                className="p-3 bg-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-110"
              >
                <img src="images/email.png" alt="Email" className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
