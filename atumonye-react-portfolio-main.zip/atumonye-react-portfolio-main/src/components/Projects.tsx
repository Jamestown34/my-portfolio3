
import React from 'react';

const Projects = () => {
  const projects = [
    {
      title: "Movie Recommendation System",
      description: "Built a recommendation engine that leverages genre and plot overview data to generate personalized movie suggestions—addressing a real-world need for smarter, user-focused content discovery.",
      image: "./images/Screenshot%20(41).png",
      technologies: ["Python", "TMBD API", "Pandas", "Scikit-learn", "Gradio Web interface"],
      github: "https://github.com/Jamestown34/Movie-Recommendation/blob/main/TMBD%20MOVIES%20.ipynb",
      demo: "https://github.com/Jamestown34/Movie-Recommendation/blob/main/README.md"
    },
    {
      title: "Ad Spend Performance Optimization: Maximizing ROI with Data",
      description: "Analyzed ad campaign data to assess ROAS, ACOS, and conversions. Identified underperforming keywords and spending inefficiencies to improve targeting, boost returns, and support smarter digital ad strategies.",
      image: "./images/amazon_ads.png",
      technologies: ["Python", "Excel", "Pandas", "Pivot Tables"],
      github: "https://github.com/Jamestown34/Amazon_ads_Analysis/blob/main/README.md",
      demo: "https://github.com/Jamestown34/Amazon_ads_Analysis/blob/main/README.md"
    },
    {
      title: "Pneumonia Prediction Using X-ray Images",
      description: "Developed a deep learning model in Python to analyze chest X-ray images and accurately detect pneumonia—supporting faster, more reliable medical diagnosis using AI-powered image classification.",
      image: "./images/project_1.jpg",
      technologies: ["Python", "Machine Learning", "TensorFlow", "CNN"],
      github: "https://github.com/Jamestown34/Pneumonia-X-ray-prediction",
      demo: "https://github.com/Jamestown34/Pneumonia-X-ray-prediction/blob/main/README.md"
    },
    {
      title: "Returns Analysis: Reducing Product Returns with Data",
      description: "Analyzed fashion return data to uncover key drivers of product returns. Identified high-return items and offered actionable insights to reduce return rates and boost customer satisfaction.",
      image: "./images/return_anlysis.png",
      technologies: ["Python", "Excel", "Pandas", "Pivot Tables"],
      github: "https://github.com/Jamestown34/Amazon-_return_analysis/blob/main/README.md",
      demo: "https://github.com/Jamestown34/Amazon-_return_analysis/blob/main/README.md"
    },
    {
      title: "Nigeria's Trade-Intelligence-from-2019-2023 (HS85)",
      description: "Explored five years of Nigeria's import data to uncover trade patterns and dependencies, offering insights for business strategy, supply chain planning, and policy decisions.",
      image: "./images/tradding.png",
      technologies: ["Python", "Excel", "Pandas", "Pivot Tables"],
      github: "https://github.com/Jamestown34/Trade-Intelligence-from-2019-2023/blob/main/vertopal.com_Analysis.pdf",
      demo: "https://github.com/Jamestown34/Trade-Intelligence-from-2019-2023/blob/main/README.md"
    },
    {
      title: "Breast Cancer Prediction & Analysis",
      description: "Applied clustering algorithms to breast cancer datasets to uncover patterns supporting early detection. The project enhanced data-driven insights for classification and encouraged better diagnostic decisions in healthcare systems.",
      image: "./images/project_3.jpg",
      technologies: ["Python", "Scikit-learn", "Clustering"],
      github: "https://github.com/Jamestown34/Breast-Cancer-Unsupervised-learning-Prediction",
      demo: "https://github.com/Jamestown34/Breast-Cancer-Unsupervised-learning-Prediction/blob/main/README.md"
    }
  ];

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-lg text-gray-600 mb-4">Browse Through My</p>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">Projects</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Here are some of the projects I've worked on, showcasing my skills in data science, Machine Learning and AI
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={project.title}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {project.title}
                </h3>
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {project.description}
                </p>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.technologies.map((tech) => (
                    <span
                      key={tech}
                      className="px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                
                <div className="flex space-x-4">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 bg-gray-900 text-white text-center py-2 px-4 rounded-lg hover:bg-gray-800 transition-colors duration-200"
                  >
                    GitHub
                  </a>
                  <a
                    href={project.demo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 bg-blue-600 text-white text-center py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                  >
                    Read
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
