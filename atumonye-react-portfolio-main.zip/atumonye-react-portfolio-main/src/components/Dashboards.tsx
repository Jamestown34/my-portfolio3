
import React from 'react';

const Dashboards = () => {
  const dashboards = [
    {
      title: "Dashboard 1",
      image: "images/dashboard1.png",
      link: "#"
    },
    {
      title: "Dashboard 2",
      image: "images/dashboard2.png",
      link: "#"
    },
    {
      title: "Dashboard 3",
      image: "images/dashboard3.png",
      link: "#"
    }
  ];

  return (
    <section id="dashboards" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-lg text-gray-600 mb-4">View My Latest</p>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">Dashboards</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Below are some of my most recent dashboard projects created with BI Tools. These dashboards provide comprehensive insights and visualizations for various datasets and scenarios.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {dashboards.map((dashboard, index) => (
            <a
              key={dashboard.title}
              href={dashboard.link}
              target="_blank"
              rel="noopener noreferrer"
              className="group bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={dashboard.image}
                  alt={dashboard.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 text-center group-hover:text-blue-600 transition-colors duration-200">
                  {dashboard.title}
                </h3>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Dashboards;
