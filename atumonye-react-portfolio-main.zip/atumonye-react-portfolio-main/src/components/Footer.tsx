
import React from 'react';

const Footer = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <nav className="mb-8">
          <div className="flex justify-center">
            <ul className="flex flex-wrap justify-center space-x-8">
              {['About', 'Skills', 'Projects', 'Contact'].map((item) => (
                <li key={item}>
                  <button
                    onClick={() => scrollToSection(item.toLowerCase().replace('skills', 'experience'))}
                    className="text-gray-300 hover:text-white transition-colors duration-200"
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </nav>
        
        <div className="text-center">
          <p className="text-gray-400">
            Copyright © 2023 Atumonye James. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
