
import React from 'react';

const Certifications = () => {
  const certifications = [
    {
      title: "Complete Data Science Certificate",
      image: "images/certificate1.png",
      organization: "Udemy",
      date: "2023"
    },
    {
      title: "Internship Completion Certificate",
      image: "images/certificate2.png",
      organization: "Zidio Development",
      date: "2024"
    },
    {
      title: "Course Completion Certificate",
      image: "images/certificate3.png",
      organization: "Amdari",
      date: "2025"
    }
  ];

  return (
    <section id="certifications" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-lg text-gray-600 mb-4">Check Out My</p>
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">Certifications</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Here are some of my most significant certifications that demonstrate my skills and expertise in various domains.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {certifications.map((cert, index) => (
            <div
              key={cert.title}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={cert.image}
                  alt={cert.title}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  {cert.title}
                </h3>
                <div className="space-y-2 text-gray-600">
                  <p><strong>Organization:</strong> {cert.organization}</p>
                  <p><strong>Date:</strong> {cert.date}</p>
                </div>
                <a
                  href={cert.image}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors duration-200"
                >
                  View Certificate
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">Download My CV</h3>
          <a
            href="CV.pdf"
            download
            className="inline-block bg-primary text-white px-8 py-3 rounded-full font-semibold hover:bg-primary/90 transition-all duration-300 hover:scale-105"
          >
            Download My CV
          </a>
        </div>
      </div>
    </section>
  );
};

export default Certifications;
