
import React from 'react';

const Skills = () => {
  const skillCategories = [
    {
      title: "Programming",
      skills: [
        { name: "Python", level: "Intermediate" },
        { name: "SQL", level: "Intermediate" }
      ]
    },
    {
      title: "Databases",
      skills: [
        { name: "BigQuery", level: "Intermediate" },
        { name: "SQL Server", level: "Intermediate" }
      ]
    },
    {
      title: "BI Tools",
      skills: [
        { name: "Tableau", level: "Intermediate" },
        { name: "Power BI", level: "Experienced" }
      ]
    },
    {
      title: "Spreadsheets",
      skills: [
        { name: "Excel", level: "Experienced" },
        { name: "Google Sheets", level: "Intermediate" }
      ]
    }
  ];

  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-8">SkillSet</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            I have a well-rounded skill set in data analytics, covering programming, databases, BI tools, and spreadsheets. 
            Through hands-on projects and certifications, I have continuously refined my expertise. Below is a glimpse of my capabilities.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skillCategories.map((category, index) => (
            <div
              key={category.title}
              className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 hover:scale-105 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <h3 className="text-xl font-bold text-gray-900 mb-6 text-center">
                {category.title}
              </h3>
              <div className="space-y-4">
                {category.skills.map((skill) => (
                  <div key={skill.name} className="flex items-center space-x-3">
                    <img
                      src="images/checkmarkgood.jpg"
                      alt="Checkmark"
                      className="w-6 h-6"
                    />
                    <div>
                      <h4 className="font-semibold text-gray-900">{skill.name}</h4>
                      <p className="text-sm text-gray-600">{skill.level}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
