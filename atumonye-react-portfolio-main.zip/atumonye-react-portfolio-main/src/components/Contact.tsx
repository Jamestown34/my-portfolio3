
import React from 'react';

const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-gray-900 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <p className="text-lg text-gray-300 mb-4">Get in Touch</p>
          <h2 className="text-4xl lg:text-5xl font-bold mb-8">Contact Me</h2>
        </div>

        <div className="flex flex-col md:flex-row justify-center items-center gap-8">
          <div className="flex items-center space-x-4 bg-gray-800 rounded-xl p-6 hover:bg-gray-700 transition-colors duration-300">
            <img src="./images/email.png" alt="Email icon" className="w-8 h-8" />
            <div>
              <p className="text-gray-300">Email</p>
              <a
                href="mailto:chuksjames05@gmail.com"
                className="text-white hover:text-blue-400 transition-colors duration-200 font-semibold"
              >
                chuksjames05@gmail.com
              </a>
            </div>
          </div>

          <div className="flex items-center space-x-4 bg-gray-800 rounded-xl p-6 hover:bg-gray-700 transition-colors duration-300">
            <img src="./images/linkedin.png" alt="LinkedIn icon" className="w-8 h-8" />
            <div>
              <p className="text-gray-300">LinkedIn</p>
              <a
                href="https://www.linkedin.com/in/atumonye-james-a81147267/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-white hover:text-blue-400 transition-colors duration-200 font-semibold"
              >
                Connect with me
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
